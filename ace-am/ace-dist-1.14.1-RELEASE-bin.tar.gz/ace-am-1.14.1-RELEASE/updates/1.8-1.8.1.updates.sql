create index idx_collection_storage on collection(storage);
create index idx_collection_name on collection(name);
create index idx_collection_colgroup on collection(colgroup);
create index idx_collection_state on collection(state);
